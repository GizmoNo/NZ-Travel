﻿namespace NZ_Travel
{
    partial class frmTour
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstCostItems = new System.Windows.Forms.ListBox();
            this.txtMarkUp = new System.Windows.Forms.TextBox();
            this.txtTravelDistance = new System.Windows.Forms.TextBox();
            this.txtMaxPeople = new System.Windows.Forms.TextBox();
            this.txtTourID = new System.Windows.Forms.TextBox();
            this.lblTourID = new System.Windows.Forms.Label();
            this.lblStartDate = new System.Windows.Forms.Label();
            this.lblEndDate = new System.Windows.Forms.Label();
            this.lblMaxPeople = new System.Windows.Forms.Label();
            this.lvlTravelDistance = new System.Windows.Forms.Label();
            this.lblMarkUp = new System.Windows.Forms.Label();
            this.cboType = new System.Windows.Forms.ComboBox();
            this.lblTotalCostPrice = new System.Windows.Forms.Label();
            this.lblPriceCost = new System.Windows.Forms.Label();
            this.btnOK = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.lblName = new System.Windows.Forms.Label();
            this.lblType = new System.Windows.Forms.Label();
            this.lblCostAmount = new System.Windows.Forms.Label();
            this.txtTourName = new System.Windows.Forms.TextBox();
            this.lblTourName = new System.Windows.Forms.Label();
            this.dtpStartDate = new System.Windows.Forms.DateTimePicker();
            this.dtpEndDate = new System.Windows.Forms.DateTimePicker();
            this.lblTotalTourCost = new System.Windows.Forms.Label();
            this.lblTotalPriceTour = new System.Windows.Forms.Label();
            this.lblTotalPricePerPerson = new System.Windows.Forms.Label();
            this.lblTotalPricePerson = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lstCostItems
            // 
            this.lstCostItems.FormattingEnabled = true;
            this.lstCostItems.Location = new System.Drawing.Point(217, 22);
            this.lstCostItems.Name = "lstCostItems";
            this.lstCostItems.Size = new System.Drawing.Size(311, 329);
            this.lstCostItems.TabIndex = 0;
            // 
            // txtMarkUp
            // 
            this.txtMarkUp.Location = new System.Drawing.Point(12, 355);
            this.txtMarkUp.Name = "txtMarkUp";
            this.txtMarkUp.Size = new System.Drawing.Size(200, 20);
            this.txtMarkUp.TabIndex = 1;
            this.txtMarkUp.Text = "0";
            this.txtMarkUp.TextChanged += new System.EventHandler(this.txtMarkUp_TextChanged);
            // 
            // txtTravelDistance
            // 
            this.txtTravelDistance.Location = new System.Drawing.Point(12, 294);
            this.txtTravelDistance.Name = "txtTravelDistance";
            this.txtTravelDistance.Size = new System.Drawing.Size(200, 20);
            this.txtTravelDistance.TabIndex = 2;
            this.txtTravelDistance.Text = "0";
            this.txtTravelDistance.TextChanged += new System.EventHandler(this.txtTravelDistance_TextChanged);
            // 
            // txtMaxPeople
            // 
            this.txtMaxPeople.Location = new System.Drawing.Point(12, 243);
            this.txtMaxPeople.Name = "txtMaxPeople";
            this.txtMaxPeople.Size = new System.Drawing.Size(200, 20);
            this.txtMaxPeople.TabIndex = 3;
            this.txtMaxPeople.Text = "0";
            this.txtMaxPeople.TextChanged += new System.EventHandler(this.txtMaxPeople_TextChanged);
            // 
            // txtTourID
            // 
            this.txtTourID.Location = new System.Drawing.Point(12, 29);
            this.txtTourID.Name = "txtTourID";
            this.txtTourID.Size = new System.Drawing.Size(200, 20);
            this.txtTourID.TabIndex = 6;
            // 
            // lblTourID
            // 
            this.lblTourID.AutoSize = true;
            this.lblTourID.Location = new System.Drawing.Point(9, 9);
            this.lblTourID.Name = "lblTourID";
            this.lblTourID.Size = new System.Drawing.Size(43, 13);
            this.lblTourID.TabIndex = 7;
            this.lblTourID.Text = "Tour ID";
            // 
            // lblStartDate
            // 
            this.lblStartDate.AutoSize = true;
            this.lblStartDate.Location = new System.Drawing.Point(9, 115);
            this.lblStartDate.Name = "lblStartDate";
            this.lblStartDate.Size = new System.Drawing.Size(55, 13);
            this.lblStartDate.TabIndex = 8;
            this.lblStartDate.Text = "Start Date";
            // 
            // lblEndDate
            // 
            this.lblEndDate.AutoSize = true;
            this.lblEndDate.Location = new System.Drawing.Point(9, 171);
            this.lblEndDate.Name = "lblEndDate";
            this.lblEndDate.Size = new System.Drawing.Size(52, 13);
            this.lblEndDate.TabIndex = 9;
            this.lblEndDate.Text = "End Date";
            // 
            // lblMaxPeople
            // 
            this.lblMaxPeople.AutoSize = true;
            this.lblMaxPeople.Location = new System.Drawing.Point(9, 227);
            this.lblMaxPeople.Name = "lblMaxPeople";
            this.lblMaxPeople.Size = new System.Drawing.Size(63, 13);
            this.lblMaxPeople.TabIndex = 10;
            this.lblMaxPeople.Text = "Max People";
            // 
            // lvlTravelDistance
            // 
            this.lvlTravelDistance.AutoSize = true;
            this.lvlTravelDistance.Location = new System.Drawing.Point(9, 278);
            this.lvlTravelDistance.Name = "lvlTravelDistance";
            this.lvlTravelDistance.Size = new System.Drawing.Size(82, 13);
            this.lvlTravelDistance.TabIndex = 11;
            this.lvlTravelDistance.Text = "Travel Distance";
            // 
            // lblMarkUp
            // 
            this.lblMarkUp.AutoSize = true;
            this.lblMarkUp.Location = new System.Drawing.Point(9, 338);
            this.lblMarkUp.Name = "lblMarkUp";
            this.lblMarkUp.Size = new System.Drawing.Size(61, 13);
            this.lblMarkUp.TabIndex = 12;
            this.lblMarkUp.Text = "%MarkUp%";
            // 
            // cboType
            // 
            this.cboType.FormattingEnabled = true;
            this.cboType.Location = new System.Drawing.Point(217, 357);
            this.cboType.Name = "cboType";
            this.cboType.Size = new System.Drawing.Size(121, 21);
            this.cboType.TabIndex = 13;
            // 
            // lblTotalCostPrice
            // 
            this.lblTotalCostPrice.AutoSize = true;
            this.lblTotalCostPrice.Location = new System.Drawing.Point(584, 52);
            this.lblTotalCostPrice.Name = "lblTotalCostPrice";
            this.lblTotalCostPrice.Size = new System.Drawing.Size(13, 13);
            this.lblTotalCostPrice.TabIndex = 14;
            this.lblTotalCostPrice.Text = "0";
            // 
            // lblPriceCost
            // 
            this.lblPriceCost.AutoSize = true;
            this.lblPriceCost.Location = new System.Drawing.Point(534, 29);
            this.lblPriceCost.Name = "lblPriceCost";
            this.lblPriceCost.Size = new System.Drawing.Size(135, 13);
            this.lblPriceCost.TabIndex = 15;
            this.lblPriceCost.Text = "Total Cost Price Calculated";
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(550, 415);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(75, 23);
            this.btnOK.TabIndex = 16;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(453, 415);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 17;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(217, 395);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 18;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.Location = new System.Drawing.Point(453, 355);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(75, 23);
            this.btnEdit.TabIndex = 19;
            this.btnEdit.Text = "Edit";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(344, 355);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 20;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(227, 6);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(35, 13);
            this.lblName.TabIndex = 21;
            this.lblName.Text = "Name";
            // 
            // lblType
            // 
            this.lblType.AutoSize = true;
            this.lblType.Location = new System.Drawing.Point(341, 6);
            this.lblType.Name = "lblType";
            this.lblType.Size = new System.Drawing.Size(31, 13);
            this.lblType.TabIndex = 22;
            this.lblType.Text = "Type";
            // 
            // lblCostAmount
            // 
            this.lblCostAmount.AutoSize = true;
            this.lblCostAmount.Location = new System.Drawing.Point(450, 6);
            this.lblCostAmount.Name = "lblCostAmount";
            this.lblCostAmount.Size = new System.Drawing.Size(67, 13);
            this.lblCostAmount.TabIndex = 23;
            this.lblCostAmount.Text = "Cost Amount";
            // 
            // txtTourName
            // 
            this.txtTourName.Location = new System.Drawing.Point(12, 81);
            this.txtTourName.Name = "txtTourName";
            this.txtTourName.Size = new System.Drawing.Size(200, 20);
            this.txtTourName.TabIndex = 24;
            // 
            // lblTourName
            // 
            this.lblTourName.AutoSize = true;
            this.lblTourName.Location = new System.Drawing.Point(9, 65);
            this.lblTourName.Name = "lblTourName";
            this.lblTourName.Size = new System.Drawing.Size(60, 13);
            this.lblTourName.TabIndex = 25;
            this.lblTourName.Text = "Tour Name";
            // 
            // dtpStartDate
            // 
            this.dtpStartDate.Location = new System.Drawing.Point(12, 131);
            this.dtpStartDate.Name = "dtpStartDate";
            this.dtpStartDate.Size = new System.Drawing.Size(200, 20);
            this.dtpStartDate.TabIndex = 26;
            this.dtpStartDate.ValueChanged += new System.EventHandler(this.dtpStartDate_ValueChanged);
            // 
            // dtpEndDate
            // 
            this.dtpEndDate.Location = new System.Drawing.Point(12, 187);
            this.dtpEndDate.Name = "dtpEndDate";
            this.dtpEndDate.Size = new System.Drawing.Size(200, 20);
            this.dtpEndDate.TabIndex = 27;
            this.dtpEndDate.Value = new System.DateTime(2018, 5, 30, 11, 15, 0, 0);
            this.dtpEndDate.ValueChanged += new System.EventHandler(this.dtpEndDate_ValueChanged);
            // 
            // lblTotalTourCost
            // 
            this.lblTotalTourCost.AutoSize = true;
            this.lblTotalTourCost.Location = new System.Drawing.Point(584, 187);
            this.lblTotalTourCost.Name = "lblTotalTourCost";
            this.lblTotalTourCost.Size = new System.Drawing.Size(13, 13);
            this.lblTotalTourCost.TabIndex = 28;
            this.lblTotalTourCost.Text = "0";
            // 
            // lblTotalPriceTour
            // 
            this.lblTotalPriceTour.AutoSize = true;
            this.lblTotalPriceTour.Location = new System.Drawing.Point(557, 155);
            this.lblTotalPriceTour.Name = "lblTotalPriceTour";
            this.lblTotalPriceTour.Size = new System.Drawing.Size(94, 13);
            this.lblTotalPriceTour.TabIndex = 29;
            this.lblTotalPriceTour.Text = "Total Cost Of Tour";
            // 
            // lblTotalPricePerPerson
            // 
            this.lblTotalPricePerPerson.AutoSize = true;
            this.lblTotalPricePerPerson.Location = new System.Drawing.Point(584, 115);
            this.lblTotalPricePerPerson.Name = "lblTotalPricePerPerson";
            this.lblTotalPricePerPerson.Size = new System.Drawing.Size(13, 13);
            this.lblTotalPricePerPerson.TabIndex = 30;
            this.lblTotalPricePerPerson.Text = "0";
            // 
            // lblTotalPricePerson
            // 
            this.lblTotalPricePerson.AutoSize = true;
            this.lblTotalPricePerson.Location = new System.Drawing.Point(557, 88);
            this.lblTotalPricePerson.Name = "lblTotalPricePerson";
            this.lblTotalPricePerson.Size = new System.Drawing.Size(86, 13);
            this.lblTotalPricePerson.TabIndex = 31;
            this.lblTotalPricePerson.Text = "Price Per Person";
            // 
            // frmTour
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(669, 450);
            this.Controls.Add(this.lblTotalPricePerson);
            this.Controls.Add(this.lblTotalPricePerPerson);
            this.Controls.Add(this.lblTotalPriceTour);
            this.Controls.Add(this.lblTotalTourCost);
            this.Controls.Add(this.dtpEndDate);
            this.Controls.Add(this.dtpStartDate);
            this.Controls.Add(this.lblTourName);
            this.Controls.Add(this.txtTourName);
            this.Controls.Add(this.lblCostAmount);
            this.Controls.Add(this.lblType);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.lblPriceCost);
            this.Controls.Add(this.lblTotalCostPrice);
            this.Controls.Add(this.cboType);
            this.Controls.Add(this.lblMarkUp);
            this.Controls.Add(this.lvlTravelDistance);
            this.Controls.Add(this.lblMaxPeople);
            this.Controls.Add(this.lblEndDate);
            this.Controls.Add(this.lblStartDate);
            this.Controls.Add(this.lblTourID);
            this.Controls.Add(this.txtTourID);
            this.Controls.Add(this.txtMaxPeople);
            this.Controls.Add(this.txtTravelDistance);
            this.Controls.Add(this.txtMarkUp);
            this.Controls.Add(this.lstCostItems);
            this.Name = "frmTour";
            this.Text = "NZ Travel Tours Calculator";
            this.Load += new System.EventHandler(this.frmTour_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lstCostItems;
        private System.Windows.Forms.TextBox txtMarkUp;
        private System.Windows.Forms.TextBox txtTravelDistance;
        private System.Windows.Forms.TextBox txtMaxPeople;
        private System.Windows.Forms.TextBox txtTourID;
        private System.Windows.Forms.Label lblTourID;
        private System.Windows.Forms.Label lblStartDate;
        private System.Windows.Forms.Label lblEndDate;
        private System.Windows.Forms.Label lblMaxPeople;
        private System.Windows.Forms.Label lvlTravelDistance;
        private System.Windows.Forms.Label lblMarkUp;
        private System.Windows.Forms.ComboBox cboType;
        private System.Windows.Forms.Label lblTotalCostPrice;
        private System.Windows.Forms.Label lblPriceCost;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblType;
        private System.Windows.Forms.Label lblCostAmount;
        private System.Windows.Forms.TextBox txtTourName;
        private System.Windows.Forms.Label lblTourName;
        private System.Windows.Forms.DateTimePicker dtpStartDate;
        private System.Windows.Forms.DateTimePicker dtpEndDate;
        private System.Windows.Forms.Label lblTotalTourCost;
        private System.Windows.Forms.Label lblTotalPriceTour;
        private System.Windows.Forms.Label lblTotalPricePerPerson;
        private System.Windows.Forms.Label lblTotalPricePerson;
    }
}