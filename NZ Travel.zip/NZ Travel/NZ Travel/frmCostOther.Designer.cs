﻿namespace NZ_Travel
{
    partial class frmCostOther
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtDiscription = new System.Windows.Forms.TextBox();
            this.lblDiscription = new System.Windows.Forms.Label();
            this.lblCost = new System.Windows.Forms.Label();
            this.lblReason = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtDiscription
            // 
            this.txtDiscription.Location = new System.Drawing.Point(12, 77);
            this.txtDiscription.Name = "txtDiscription";
            this.txtDiscription.Size = new System.Drawing.Size(232, 20);
            this.txtDiscription.TabIndex = 12;
            // 
            // lblDiscription
            // 
            this.lblDiscription.AutoSize = true;
            this.lblDiscription.Location = new System.Drawing.Point(9, 59);
            this.lblDiscription.Name = "lblDiscription";
            this.lblDiscription.Size = new System.Drawing.Size(56, 13);
            this.lblDiscription.TabIndex = 13;
            this.lblDiscription.Text = "Discription";
            // 
            // lblCost
            // 
            this.lblCost.AutoSize = true;
            this.lblCost.Location = new System.Drawing.Point(9, 100);
            this.lblCost.Name = "lblCost";
            this.lblCost.Size = new System.Drawing.Size(40, 13);
            this.lblCost.TabIndex = 14;
            this.lblCost.Text = "$Cost$";
            // 
            // lblReason
            // 
            this.lblReason.AutoSize = true;
            this.lblReason.Location = new System.Drawing.Point(9, 20);
            this.lblReason.Name = "lblReason";
            this.lblReason.Size = new System.Drawing.Size(44, 13);
            this.lblReason.TabIndex = 15;
            this.lblReason.Text = "Reason";
            // 
            // frmCostOther
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(266, 208);
            this.Controls.Add(this.lblReason);
            this.Controls.Add(this.lblCost);
            this.Controls.Add(this.lblDiscription);
            this.Controls.Add(this.txtDiscription);
            this.Name = "frmCostOther";
            this.Text = "frmCostOther";
            this.Controls.SetChildIndex(this.txtDiscription, 0);
            this.Controls.SetChildIndex(this.lblDiscription, 0);
            this.Controls.SetChildIndex(this.lblCost, 0);
            this.Controls.SetChildIndex(this.lblReason, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtDiscription;
        private System.Windows.Forms.Label lblDiscription;
        private System.Windows.Forms.Label lblCost;
        private System.Windows.Forms.Label lblReason;
    }
}
