﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace NZ_Travel
{
    public partial class frmCostStaff : NZ_Travel.frmCost
    {
        public frmCostStaff()
        {
            InitializeComponent();
        }

        protected override void UpdateDisplay()
        {
            base.UpdateDisplay();
            clsCostStaff lcCost = (clsCostStaff)_NewCost;
            txtType.Text = lcCost.Position;
        }

        protected override void PushData()
        {
            base.PushData();
            clsCostStaff lcCost = (clsCostStaff)_NewCost;
            lcCost.Position = txtType.Text;
        }


    }
}
