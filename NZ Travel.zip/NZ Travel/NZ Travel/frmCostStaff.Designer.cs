﻿namespace NZ_Travel
{
    partial class frmCostStaff
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblName = new System.Windows.Forms.Label();
            this.lblJobPosition = new System.Windows.Forms.Label();
            this.lblPayRate = new System.Windows.Forms.Label();
            this.txtType = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(9, 20);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(35, 13);
            this.lblName.TabIndex = 12;
            this.lblName.Text = "Name";
            // 
            // lblJobPosition
            // 
            this.lblJobPosition.AutoSize = true;
            this.lblJobPosition.Location = new System.Drawing.Point(9, 61);
            this.lblJobPosition.Name = "lblJobPosition";
            this.lblJobPosition.Size = new System.Drawing.Size(64, 13);
            this.lblJobPosition.TabIndex = 13;
            this.lblJobPosition.Text = "Job Position";
            // 
            // lblPayRate
            // 
            this.lblPayRate.AutoSize = true;
            this.lblPayRate.Location = new System.Drawing.Point(9, 100);
            this.lblPayRate.Name = "lblPayRate";
            this.lblPayRate.Size = new System.Drawing.Size(98, 13);
            this.lblPayRate.TabIndex = 14;
            this.lblPayRate.Text = "$PayRate PerDay$";
            // 
            // txtType
            // 
            this.txtType.Location = new System.Drawing.Point(12, 77);
            this.txtType.Name = "txtType";
            this.txtType.Size = new System.Drawing.Size(232, 20);
            this.txtType.TabIndex = 15;
            // 
            // frmStaff1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(266, 227);
            this.Controls.Add(this.txtType);
            this.Controls.Add(this.lblPayRate);
            this.Controls.Add(this.lblJobPosition);
            this.Controls.Add(this.lblName);
            this.Name = "frmStaff1";
            this.Text = "frmCostStaff";
            this.Controls.SetChildIndex(this.lblName, 0);
            this.Controls.SetChildIndex(this.lblJobPosition, 0);
            this.Controls.SetChildIndex(this.lblPayRate, 0);
            this.Controls.SetChildIndex(this.txtType, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblJobPosition;
        private System.Windows.Forms.Label lblPayRate;
        private System.Windows.Forms.TextBox txtType;
    }
}
