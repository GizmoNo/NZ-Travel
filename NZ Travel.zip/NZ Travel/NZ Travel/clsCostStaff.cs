﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NZ_Travel
{
    [Serializable]
    class clsCostStaff : clsNewCost
    {
        private string _Position;
        private static frmCostStaff _CostStaff = new frmCostStaff();

        public string Position
        { get => _Position;
          set => _Position = value;
        }

        public override bool ViewEdit()
        {
            return _CostStaff.ShowDialog(this);

        }

        protected override string TypeOfCost()
        {
            return "Staff";
        }

        public override decimal Calculate(clsTour prTour)
        {
            return InputAmount * Convert.ToDecimal((prTour.DateEnd.Date - prTour.DateStart.Date).TotalDays);
        }

    }
}
