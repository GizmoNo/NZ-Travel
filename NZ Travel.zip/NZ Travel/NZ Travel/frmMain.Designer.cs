﻿namespace NZ_Travel
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstTours = new System.Windows.Forms.ListBox();
            this.lblSortBy = new System.Windows.Forms.Label();
            this.btnMainEdit = new System.Windows.Forms.Button();
            this.btnMainAdd = new System.Windows.Forms.Button();
            this.btnMainDelete = new System.Windows.Forms.Button();
            this.lblNameDate1 = new System.Windows.Forms.Label();
            this.lblEndDate = new System.Windows.Forms.Label();
            this.lblPrice = new System.Windows.Forms.Label();
            this.lblStartDate = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.cboSortBy = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lstTours
            // 
            this.lstTours.FormattingEnabled = true;
            this.lstTours.Location = new System.Drawing.Point(138, 38);
            this.lstTours.Name = "lstTours";
            this.lstTours.Size = new System.Drawing.Size(369, 264);
            this.lstTours.TabIndex = 0;
            this.lstTours.DoubleClick += new System.EventHandler(this.lstTours_DoubleClick);
            // 
            // lblSortBy
            // 
            this.lblSortBy.AutoSize = true;
            this.lblSortBy.Location = new System.Drawing.Point(50, 146);
            this.lblSortBy.Name = "lblSortBy";
            this.lblSortBy.Size = new System.Drawing.Size(41, 13);
            this.lblSortBy.TabIndex = 1;
            this.lblSortBy.Text = "Sort By";
            // 
            // btnMainEdit
            // 
            this.btnMainEdit.Location = new System.Drawing.Point(138, 336);
            this.btnMainEdit.Name = "btnMainEdit";
            this.btnMainEdit.Size = new System.Drawing.Size(119, 23);
            this.btnMainEdit.TabIndex = 4;
            this.btnMainEdit.Text = "Edit";
            this.btnMainEdit.UseVisualStyleBackColor = true;
            this.btnMainEdit.Click += new System.EventHandler(this.btnMainEdit_Click);
            // 
            // btnMainAdd
            // 
            this.btnMainAdd.Location = new System.Drawing.Point(138, 307);
            this.btnMainAdd.Name = "btnMainAdd";
            this.btnMainAdd.Size = new System.Drawing.Size(119, 23);
            this.btnMainAdd.TabIndex = 5;
            this.btnMainAdd.Text = "Add";
            this.btnMainAdd.UseVisualStyleBackColor = true;
            this.btnMainAdd.Click += new System.EventHandler(this.btnMainAdd_Click);
            // 
            // btnMainDelete
            // 
            this.btnMainDelete.Location = new System.Drawing.Point(388, 308);
            this.btnMainDelete.Name = "btnMainDelete";
            this.btnMainDelete.Size = new System.Drawing.Size(119, 23);
            this.btnMainDelete.TabIndex = 6;
            this.btnMainDelete.Text = "Delete";
            this.btnMainDelete.UseVisualStyleBackColor = true;
            this.btnMainDelete.Click += new System.EventHandler(this.btnMainDelete_Click);
            // 
            // lblNameDate1
            // 
            this.lblNameDate1.AutoSize = true;
            this.lblNameDate1.Location = new System.Drawing.Point(135, 22);
            this.lblNameDate1.Name = "lblNameDate1";
            this.lblNameDate1.Size = new System.Drawing.Size(35, 13);
            this.lblNameDate1.TabIndex = 7;
            this.lblNameDate1.Text = "Name";
            // 
            // lblEndDate
            // 
            this.lblEndDate.AutoSize = true;
            this.lblEndDate.Location = new System.Drawing.Point(326, 22);
            this.lblEndDate.Name = "lblEndDate";
            this.lblEndDate.Size = new System.Drawing.Size(52, 13);
            this.lblEndDate.TabIndex = 8;
            this.lblEndDate.Text = "End Date";
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrice.Location = new System.Drawing.Point(428, 22);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(31, 13);
            this.lblPrice.TabIndex = 9;
            this.lblPrice.Text = "Price";
            // 
            // lblStartDate
            // 
            this.lblStartDate.AutoSize = true;
            this.lblStartDate.Location = new System.Drawing.Point(226, 22);
            this.lblStartDate.Name = "lblStartDate";
            this.lblStartDate.Size = new System.Drawing.Size(55, 13);
            this.lblStartDate.TabIndex = 10;
            this.lblStartDate.Text = "Start Date";
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(388, 336);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(119, 23);
            this.btnClose.TabIndex = 11;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // cboSortBy
            // 
            this.cboSortBy.FormattingEnabled = true;
            this.cboSortBy.Location = new System.Drawing.Point(12, 162);
            this.cboSortBy.Name = "cboSortBy";
            this.cboSortBy.Size = new System.Drawing.Size(120, 21);
            this.cboSortBy.TabIndex = 12;
            this.cboSortBy.SelectedIndexChanged += new System.EventHandler(this.cboSortBy_SelectedIndexChanged);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(520, 371);
            this.Controls.Add(this.cboSortBy);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lblStartDate);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.lblEndDate);
            this.Controls.Add(this.lblNameDate1);
            this.Controls.Add(this.btnMainDelete);
            this.Controls.Add(this.btnMainAdd);
            this.Controls.Add(this.btnMainEdit);
            this.Controls.Add(this.lblSortBy);
            this.Controls.Add(this.lstTours);
            this.Name = "frmMain";
            this.Text = "NZ Travel Tours Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lstTours;
        private System.Windows.Forms.Label lblSortBy;
        private System.Windows.Forms.Button btnMainEdit;
        private System.Windows.Forms.Button btnMainAdd;
        private System.Windows.Forms.Button btnMainDelete;
        private System.Windows.Forms.Label lblNameDate1;
        private System.Windows.Forms.Label lblEndDate;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Label lblStartDate;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.ComboBox cboSortBy;
    }
}

