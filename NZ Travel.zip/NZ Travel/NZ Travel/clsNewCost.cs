﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NZ_Travel
{
    [Serializable]
    public abstract class clsNewCost
    {
        private static frmCost _NewCost = new frmCost();
        

        protected abstract string TypeOfCost();

        public static readonly string[] CostType = { "Staff", "Vechicle", "Other" };

        public override string ToString()
        {
            return _Name + "\t" + "\t" + TypeOfCost() + "\t" + "\t" + _InputAmount;
        }

        private string _Name;
        private decimal _InputAmount;

        public string Name
        { get => _Name;
          set => _Name = value;
        }
        public decimal InputAmount
        { get => _InputAmount;
          set => _InputAmount = value;
        }
              
        public static clsNewCost NewCost(int prChoice)
        {
            switch (prChoice)
            {
                case 0:
                    return new clsCostStaff();


                case 1:
                    return new clsCostVechicle();

                case 2:
                    return new clsCostOther();

                default:
                    return null;


            }
        }
               

        public abstract bool ViewEdit();


        public abstract decimal Calculate(clsTour prTour);

        
    }
}
