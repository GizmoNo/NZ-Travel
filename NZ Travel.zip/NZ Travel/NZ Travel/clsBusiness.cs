﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace NZ_Travel
{
    [Serializable]
    public class clsBusiness
    {
        private static string saveFileName = "SavedTours";

        

        private static Dictionary<string, clsTour> _TourList = new Dictionary<string, clsTour>();

        public static Dictionary<string, clsTour> TourList
        {
          get => _TourList;
          set => _TourList = value;
        }

        public static void SaveTours()
        {

            using (FileStream lcFileStream = new FileStream(saveFileName, FileMode.Create))
            {
                BinaryFormatter lcFormatter = new BinaryFormatter();
                lcFormatter.Serialize(lcFileStream, _TourList);
            }
        }

        public static void LoadTours()
        {
            using (FileStream lcFileStream = new FileStream(saveFileName, FileMode.Open))
            {
                BinaryFormatter lcFormatter = new BinaryFormatter();
                _TourList = (Dictionary<string, clsTour>)
                                            lcFormatter.Deserialize(lcFileStream);
            }
        }

        public static clsTour DuplicateTour(clsTour prTour)
        {
            //Serialize the passed tour
            MemoryStream lcMemoryStream = SerializeToStream(prTour);

            //Deserialize the tour into the tour copy
            clsTour _TourCopy = (clsTour)DeserializeFromStream(lcMemoryStream);

            return _TourCopy; //Return the copy
        }

        private static clsTour DeserializeFromStream(MemoryStream prMemoryStream)
        {

            BinaryFormatter lcFormatter = new BinaryFormatter();
            prMemoryStream.Seek(0, SeekOrigin.Begin);
            clsTour lcTourCopy = (clsTour)lcFormatter.Deserialize(prMemoryStream);
            return lcTourCopy;
        }

        private static MemoryStream SerializeToStream(clsTour prTour)
        {
            MemoryStream lcStream = new MemoryStream();
            BinaryFormatter lcFormatter = new BinaryFormatter();
            lcFormatter.Serialize(lcStream, prTour);
            return lcStream;
        }
    }
}
