﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NZ_Travel
{
    public partial class frmTour : Form
    {
        

        protected clsTour _NewTour;

        bool LoadingFlag = true;

        public frmTour()
        {
            InitializeComponent();
            cboType.DataSource = clsNewCost.CostType;
            cboType.SelectedIndex = 0;
            
        }

        public bool ShowDialog(clsTour prTour)
        {
            _NewTour = prTour;
            UpdateDisplay();
            LoadingFlag = false;
            return ShowDialog() == DialogResult.OK;

        }

        

        private void btnOK_Click(object sender, EventArgs e)
        {

            if (txtTourID.Enabled && clsBusiness.TourList.ContainsKey(txtTourID.Text))
            {
                MessageBox.Show("Tour Already Exists", "Please Change the TourID");
                txtTourID.Text = "";
            }

            else if (string.IsNullOrWhiteSpace(txtTourID.Text))
            {
                MessageBox.Show("Please Enter A Tour ID");
            }

            else if (string.IsNullOrWhiteSpace(txtTourName.Text))
            {
                MessageBox.Show("Tour Name Required");
            }
            else if (string.IsNullOrWhiteSpace(txtTravelDistance.Text))
            {
                MessageBox.Show("Please Enter The Travel Distance");
            }

            else if (string.IsNullOrWhiteSpace(txtMaxPeople.Text))
            {
                MessageBox.Show("Please Enter The Maximum Amount Of People Allowed On This Tour");
            }

            else if (string.IsNullOrWhiteSpace(txtMarkUp.Text))
            {
                MessageBox.Show("Please Enter Tour Mark Up%");
            }
            else
            {
                PushData();
                DialogResult = DialogResult.OK;
            }

                        
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            
            clsNewCost lcCost = clsNewCost.NewCost(cboType.SelectedIndex);
            PushData();
            if (lcCost != null && lcCost.ViewEdit())
            {
                _NewTour.CostItems.Add(lcCost);
                UpdateDisplay();
                UpdateListBox();
            }
        }
              
        private void btnEdit_Click(object sender, EventArgs e)
        {
            if(lstCostItems.SelectedItem == null)
            {
                MessageBox.Show("No Cost Has Been Selected");
            }
            else
            {
                clsNewCost lcCost = (clsNewCost)lstCostItems.SelectedItem;
                PushData();
                if (lcCost != null && lcCost.ViewEdit())
                {
                    UpdateDisplay();
                    UpdateListBox();
                }
            }
            
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }
        private void UpdateListBox()
        {

            lstCostItems.DataSource = null;
            if (_NewTour.CostItems != null)

                lstCostItems.DataSource = _NewTour.CostItems.ToList<clsNewCost>();

        }
        protected virtual void UpdateDisplay()
        {
            txtTourID.Text = _NewTour.TourID;
            txtTourName.Text = _NewTour.TourName;
            dtpStartDate.Value = _NewTour.DateStart;
            dtpEndDate.Value = _NewTour.DateEnd;
            txtMaxPeople.Text = Convert.ToString(_NewTour.MaxPeople);
            txtTravelDistance.Text = Convert.ToString(_NewTour.TravelDistance);
            txtMarkUp.Text = Convert.ToString(_NewTour.MarkUp);

            txtTourID.Enabled = String.IsNullOrEmpty(_NewTour.TourID);

            UpdateTotals();
        }

        protected virtual void PushData()
        {
            try
            {
                _NewTour.TourID = txtTourID.Text;
                _NewTour.TourName = txtTourName.Text;
                _NewTour.DateStart = dtpStartDate.Value;
                _NewTour.DateEnd = dtpEndDate.Value;
                _NewTour.MaxPeople = Convert.ToByte(txtMaxPeople.Text);
                _NewTour.TravelDistance = Convert.ToDecimal(txtTravelDistance.Text);
                _NewTour.MarkUp = Convert.ToDecimal(txtMarkUp.Text);
            }
            catch
            {

            }

        }

        private void UpdateTotals()
        {
            lblTotalCostPrice.Text = _NewTour.CalculateTotalExpenses().ToString("$0.00");
            lblTotalTourCost.Text = _NewTour.CalculateTourTotal().ToString("$0.00");
            lblTotalPricePerPerson.Text = _NewTour.CalculatePricePerPerson().ToString("$0.00");
        }

        private void dtpStartDate_ValueChanged(object sender, EventArgs e)
        {
            if (dtpStartDate.Value < DateTime.Now)
            {
                dtpStartDate.Value = _NewTour.DateStart;
            }

            Recalculate();
        }

        private void dtpEndDate_ValueChanged(object sender, EventArgs e)
        {
            if (dtpEndDate.Value < dtpStartDate.Value)
            {
                dtpEndDate.Value = _NewTour.DateEnd;
            }
            Recalculate();
        }

        private void txtMaxPeople_TextChanged(object sender, EventArgs e)
        {
            Recalculate();
        }
                
        private void txtTravelDistance_TextChanged(object sender, EventArgs e)
        {
            Recalculate();
        }

        private void txtMarkUp_TextChanged(object sender, EventArgs e)
        {
            Recalculate();
        }

        private void frmTour_Load(object sender, EventArgs e)
        {
            UpdateListBox();
            UpdateTotals();
            
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if(lstCostItems.SelectedItem == null)
            {
                MessageBox.Show("No Cost Has Been Selected");
            }
            else
            {
                DialogResult lcResult = MessageBox.Show("Are you sure you want to delete this Cost?",
                                                                   "Important Question",
                                                                   MessageBoxButtons.YesNo);
                if (lcResult == DialogResult.Yes)
                {
                    clsNewCost TempCost = lstCostItems.SelectedItem as clsNewCost;
                    _NewTour.CostItems.Remove(TempCost);

                    UpdateListBox();
                    UpdateTotals();
                    clsBusiness.SaveTours();

                }
            }
           
        }
        private void Recalculate()
        {
            if (LoadingFlag == false)
            {
                _NewTour.CalculatePricePerPerson();
                _NewTour.CalculateTotalExpenses();
                _NewTour.CalculateTourTotal();

                PushData();
                UpdateTotals();
            }
        }
    }


}
