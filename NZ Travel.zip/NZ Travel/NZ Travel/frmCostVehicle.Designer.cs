﻿namespace NZ_Travel
{
    partial class frmCostVehicle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblVehicleID = new System.Windows.Forms.Label();
            this.lblType = new System.Windows.Forms.Label();
            this.lblKMCharge = new System.Windows.Forms.Label();
            this.txtType = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblVehicleID
            // 
            this.lblVehicleID.AutoSize = true;
            this.lblVehicleID.Location = new System.Drawing.Point(8, 20);
            this.lblVehicleID.Name = "lblVehicleID";
            this.lblVehicleID.Size = new System.Drawing.Size(56, 13);
            this.lblVehicleID.TabIndex = 12;
            this.lblVehicleID.Text = "Vehicle ID";
            // 
            // lblType
            // 
            this.lblType.AutoSize = true;
            this.lblType.Location = new System.Drawing.Point(8, 61);
            this.lblType.Name = "lblType";
            this.lblType.Size = new System.Drawing.Size(31, 13);
            this.lblType.TabIndex = 13;
            this.lblType.Text = "Type";
            // 
            // lblKMCharge
            // 
            this.lblKMCharge.AutoSize = true;
            this.lblKMCharge.Location = new System.Drawing.Point(9, 100);
            this.lblKMCharge.Name = "lblKMCharge";
            this.lblKMCharge.Size = new System.Drawing.Size(63, 13);
            this.lblKMCharge.TabIndex = 14;
            this.lblKMCharge.Text = "K-M Charge";
            // 
            // txtType
            // 
            this.txtType.Location = new System.Drawing.Point(11, 77);
            this.txtType.Name = "txtType";
            this.txtType.Size = new System.Drawing.Size(233, 20);
            this.txtType.TabIndex = 15;
            // 
            // frmCostVehicle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(266, 227);
            this.Controls.Add(this.txtType);
            this.Controls.Add(this.lblKMCharge);
            this.Controls.Add(this.lblType);
            this.Controls.Add(this.lblVehicleID);
            this.Name = "frmCostVehicle";
            this.Text = "frmCostVehicle";
            this.Controls.SetChildIndex(this.lblVehicleID, 0);
            this.Controls.SetChildIndex(this.lblType, 0);
            this.Controls.SetChildIndex(this.lblKMCharge, 0);
            this.Controls.SetChildIndex(this.txtType, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblVehicleID;
        private System.Windows.Forms.Label lblType;
        private System.Windows.Forms.Label lblKMCharge;
        private System.Windows.Forms.TextBox txtType;
    }
}
