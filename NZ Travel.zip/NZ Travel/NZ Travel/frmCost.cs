﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NZ_Travel
{
    public partial class frmCost : Form
    {

        protected clsNewCost _NewCost;
        

        
        public frmCost()
        {
            InitializeComponent();
        }


        public bool ShowDialog(clsNewCost prCost)
        {
            _NewCost = prCost;
            UpdateDisplay();

            
            return ShowDialog() == DialogResult.OK;

        }

        protected virtual void UpdateDisplay()
        {
                        
                txtName.Text = _NewCost.Name;
                txtMoney.Text = Convert.ToString(_NewCost.InputAmount);
                        
        }

        protected virtual void PushData()
        {
            _NewCost.Name = txtName.Text;
            _NewCost.InputAmount = Convert.ToDecimal(txtMoney.Text);
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            bool lcValid = true;
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("Please Enter A Cost Name");
                lcValid = false;
            }

            if (string.IsNullOrWhiteSpace(txtMoney.Text))
            {
                MessageBox.Show("Please Enter $Cost Of Service");
                lcValid = false;
            }



            if (lcValid == true)
            {
                PushData();

                DialogResult = DialogResult.OK;
            }

            

        }

       

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }

        private void txtMoney_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
            (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
           
        }
    }
}
