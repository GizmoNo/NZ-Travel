﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NZ_Travel
{
    public partial class frmMain : Form
    {
        
        private frmTour _TourForm = new frmTour();

        public readonly string[] _SortBy = { "Name", "Date" };

        private IComparer<clsTour>[] _Comparer =
            { new clsDateComparer(), new clsNameComparer() };

        public frmMain()
        {
            InitializeComponent();
            cboSortBy.DataSource = _SortBy;
            cboSortBy.SelectedIndex = 0;
            try
            {
                clsBusiness.LoadTours();
            }
            catch (Exception)
            {
                MessageBox.Show("Saved Tours Not Loaded, 1st Time Useing This Application Disregard This Message");
            }
            UpdateDisplay();
            
        }

        private void UpdateDisplay()
        {

            lstTours.DataSource = null;

            List<clsTour> lcTourList = 
                
                clsBusiness.TourList.Values.ToList();
            
            lcTourList.Sort(_Comparer[cboSortBy.SelectedIndex]);

            lstTours.DataSource = lcTourList;
           
            
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
            clsBusiness.SaveTours();
        }

        private void btnMainAdd_Click(object sender, EventArgs e)
        {
            clsTour lcTour = new clsTour();
            if (lcTour != null && lcTour.ViewEdit()) 
            {
                clsBusiness.TourList.Add(lcTour.TourID, lcTour);
                UpdateDisplay();
                clsBusiness.SaveTours();
                
            }
        }

        private void btnMainEdit_Click(object sender, EventArgs e)
        {
            if(lstTours.SelectedItem == null)
            {
                MessageBox.Show("No Tour Has Been Selected");

            }
            else
            {
                EditTour();
            }
            
        }
        private void EditTour()
        {
            clsTour lcTour = (clsTour)lstTours.SelectedItem;
            
            clsTour lcTempTour = clsBusiness.DuplicateTour(lcTour);     //Duplicate lcTour into lcTempTour

            if (lcTempTour != null && lcTempTour.ViewEdit())            //Edit the temp tour
            {
                clsBusiness.TourList.Remove(lcTour.TourID);             //if the edit was successful, remove the original
                clsBusiness.TourList.Add(lcTempTour.TourID, lcTempTour);//and add the edited version back into the Tour Dictionary

                UpdateDisplay();    //Update the screen to reflect the changes
            }
            //If the edit was cancelled, nothing happens and nothing is changed


        }
        private void btnMainDelete_Click(object sender, EventArgs e)
        {
                      
            if(lstTours.SelectedItem == null)
            {
                MessageBox.Show("No Tour Has Been Selected");
            }
            else
            {
                DialogResult lcResult = MessageBox.Show("Are you sure you want to delete this Tour?",
                                                   "Important Question",
                                                   MessageBoxButtons.YesNo);

                if (lcResult == DialogResult.Yes)
                {
                    clsTour temTour = lstTours.SelectedItem as clsTour;
                    clsBusiness.TourList.Remove(temTour.TourID);

                    UpdateDisplay();
                    clsBusiness.SaveTours();

                }
            }
        }

        
        class clsDateComparer : IComparer<clsTour>
        {
            public int Compare(clsTour prTourX, clsTour prTourY)
            {
                return prTourX.DateStart.Date.CompareTo(prTourY.DateStart.Date);
            }
        }

        class clsNameComparer : IComparer<clsTour>
        {
            public int Compare(clsTour prTourX, clsTour prTourY)
            {
                return prTourX.TourName.CompareTo(prTourY.TourName);
            }
        }

        private void cboSortBy_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateDisplay();
        }

        private void lstTours_DoubleClick(object sender, EventArgs e)
        {
            EditTour();
        }
    }
}
