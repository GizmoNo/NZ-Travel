﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NZ_Travel
{
    [Serializable]
    class clsCostVechicle :clsNewCost
    {
        private string _Type;
        private static frmCostVehicle _CostVechicle = new frmCostVehicle();

        public string Type
        {
            get => _Type;
            set => _Type = value;
        }

        public override bool ViewEdit()
        {
            return _CostVechicle.ShowDialog(this);

        }

        protected override string TypeOfCost()
        {
            return "Vechicle";
        }

        public override decimal Calculate(clsTour prTour)
        {
            return InputAmount * prTour.TravelDistance;
        }
    }
}
