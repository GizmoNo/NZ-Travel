﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NZ_Travel
{
    [Serializable]
    class clsCostOther : clsNewCost
    {

        private string _Description;
        private static frmCostOther _CostOther = new frmCostOther();

        public string Description
        { get => _Description;
          set => _Description = value;
        }

        public override bool ViewEdit()
        {
            return _CostOther.ShowDialog(this);

        }

        protected override string TypeOfCost()
        {
            return "Other";
        }

        public override decimal Calculate(clsTour prTour)
        {
            return InputAmount;
        }


    }
}
