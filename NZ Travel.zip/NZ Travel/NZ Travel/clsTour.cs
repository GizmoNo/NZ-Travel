﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NZ_Travel
{

    [Serializable]
    public class clsTour 
    {
        private static frmTour _NewTour = new frmTour();

        public List<clsNewCost> CostItems = new List<clsNewCost>();

        private string _TourName;
        private string _TourID;
        private DateTime _DateStart = DateTime.Today;
        private DateTime _DateEnd = DateTime.Today;
        private Byte _MaxPeople;
        private Decimal _TravelDistance;
        private Decimal _MarkUp;
        

        private Decimal _TotalExpenses;
        private Decimal _TourTotal;
        private Decimal _PricePerPerson;

        public override string ToString()
        {
            return TourName + "\t" +  (_DateStart.ToString("d")) + "\t" + (_DateEnd.ToString("d")) + "\t" + "$" + _TourTotal;
        }

        
        public DateTime DateStart
        { get => _DateStart;
          set => _DateStart = value;
        }
        public DateTime DateEnd
        { get => _DateEnd;
          set => _DateEnd = value;
        }
          
        public decimal TotalExpenses
        { get => _TotalExpenses;
          set => _TotalExpenses = value;
        }
        public decimal TravelDistance
        {
         get => _TravelDistance;
         set => _TravelDistance = value;
        }
        public decimal MarkUp
        {
         get => _MarkUp;
         set => _MarkUp = value;
        }
        public decimal TourTotal
        { get => _TourTotal;
          set => _TourTotal = value;
        }
        
        public decimal PricePerPerson
        {
         get => _PricePerPerson;
         set => _PricePerPerson = value;
        }
        public byte MaxPeople
        { get => _MaxPeople;
          set => _MaxPeople = value;
        }
        public string TourName { get => _TourName; set => _TourName = value; }
        public string TourID { get => _TourID; set => _TourID = value; }

        public bool ViewEdit()
        {

            return _NewTour.ShowDialog(this);

        }

        

        public decimal CalculateTotalExpenses()
        {

            decimal lcTotal = 0;

            if (CostItems != null)
            {
                foreach (clsNewCost _NewCost in CostItems)
                {
                    lcTotal += _NewCost.Calculate(this);
                }

                _TotalExpenses = lcTotal;
            }

            return lcTotal;

        }

        public decimal CalculateTourTotal()
        {
            if (TotalExpenses != 0 & MarkUp != 0)
            {
                decimal lcTotal = 0;

                lcTotal = TotalExpenses + ((TotalExpenses * 100) / MarkUp);

                TourTotal = lcTotal;

                return lcTotal;
            }
            else
                return 0;
        }

        public decimal CalculatePricePerPerson()
        {
            if (TourTotal != 0 & MaxPeople != 0)
            {
                decimal lcTotal;

                lcTotal = TourTotal / MaxPeople;

                _PricePerPerson = lcTotal;

                return lcTotal;
            }
            else

                return 0;
        }

        






    }
}
