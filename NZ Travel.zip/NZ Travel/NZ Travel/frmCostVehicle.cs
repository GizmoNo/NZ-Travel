﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace NZ_Travel
{
    public partial class frmCostVehicle : NZ_Travel.frmCost
    {
        public frmCostVehicle()
        {
            InitializeComponent();
        }

        protected override void UpdateDisplay()
        {
            base.UpdateDisplay();
            clsCostVechicle lcCost = (clsCostVechicle)_NewCost;
            txtType.Text = lcCost.Type;
        }

        protected override void PushData()
        {
            base.PushData();
            clsCostVechicle lcCost = (clsCostVechicle)_NewCost;
            lcCost.Type = txtType.Text;
        }

    }
}
