﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace NZ_Travel
{
    public partial class frmCostOther : NZ_Travel.frmCost
    {
        public frmCostOther()
        {
            InitializeComponent();
        }

        protected override void UpdateDisplay()
        {
            base.UpdateDisplay();
            clsCostOther lcCost = (clsCostOther)_NewCost;
            txtDiscription.Text = lcCost.Description;
        }

        protected override void PushData()
        {
            base.PushData();
            clsCostOther lcCost = (clsCostOther)_NewCost;
            lcCost.Description = txtDiscription.Text;
        }

        



        
    }
}
